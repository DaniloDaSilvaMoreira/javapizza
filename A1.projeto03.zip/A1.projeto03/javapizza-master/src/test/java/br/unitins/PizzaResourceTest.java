package br.unitins;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;

import org.junit.jupiter.api.Test;

import br.unitins.ecommerce.dto.pizza.PizzaDTO;
import br.unitins.ecommerce.dto.pizza.PizzaResponseDTO;
import br.unitins.ecommerce.service.pizza.PizzaService;

@QuarkusTest
public class PizzaResourceTest {
    
    @Inject
    PizzaService pizzaService;

    @Test
    public void getAllTest() {

        given()
                .when().get("/pizzas")
                .then()
                .statusCode(200);
    }

    /*************************************************************** */
    @Test
    public void insertTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(1l);
        sabores.add(2l);
        PizzaDTO pizza = new PizzaDTO(
            "CalabrezaMista",
            "Catupiry",
                1l, 
                70.0,
                20,
                2,
                2,
                2,
                sabores);

        given()
            .contentType(ContentType.JSON)
            .body(pizza)
            .when().post("/pizzas")
            .then()
                .statusCode(201)
                .body("id", notNullValue(), "nome", 
                is("CalabrezaMista"),
                "bordaPizza", is("Catupiry"),"preco",
                is(70.0F),"estoque", is("Disponivel"), 
                "tamanhoPizza.label", is("Media"),
                "tamanhoEmbalagem.label", is("Media"),
                "categoria.label", is("Salgada"),
                "sabores.get(0)", is("Calabreza"),
                "sabores.get(1)", is("Frango"));
                
    }
    /*************************************************************** */

    @Test
    public void updateTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(4l);
        sabores.add(5l);

        PizzaDTO pizza = new PizzaDTO(
            "DoceMista",
            "Chocolate ao leite",
                1l, 
                70.0,
                20,
                2,
                2,
                2,
                sabores);

        Long id = pizzaService.insert(pizza).id();

        PizzaDTO pizzaUpdate = new PizzaDTO(
            "DoceMista",
            "Chocolate ao leite",
                1l, 
                70.0,
                20,
                3,
                3,
                1,
                sabores);

        given()
          .contentType(ContentType.JSON)
          .body(pizzaUpdate)
          .when().put("/pizzas/" + id)
          .then()
             .statusCode(204);

        PizzaResponseDTO pizzaResponse = pizzaService.getById(id);

assertThat(pizzaResponse.nome(), is("DoceMista"));
assertThat(pizzaResponse.bordaPizza(), is("Chocolate ao leite"));
assertThat(pizzaResponse.nomeMarca(), is("Dominos pizza"));
assertThat(pizzaResponse.preco(), is(70.0));
assertThat(pizzaResponse.estoque(), is("Disponivel"));
assertThat(pizzaResponse.tamanhoPizza().getLabel(), is("Grande"));
assertThat(pizzaResponse.tamanhoEmbalagem().getLabel(), is("Grande"));
assertThat(pizzaResponse.categoria().getLabel(), is("Doce"));
    }

    @Test
    public void deleteTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(1l);
        sabores.add(2l);
        PizzaDTO pizza = new PizzaDTO(
            "CalabrezaMista",
            "Catupiry",
                1l, 
                70.0,
                20,
                2,
                2,
                2,
                sabores);

        Long id = pizzaService.insert(pizza).id();

        given()
          .when().delete("/pizzas/" + id)
          .then()
             .statusCode(204);

        PizzaResponseDTO pizzaResponse = null;

        try {
            
            pizzaResponse =  pizzaService.getById(id);
        } catch (Exception e) {

        }
        finally {
            assertNull(pizzaResponse);   
        }
    }

     @Test
    public void countTest() {

        given()
            .when().get("/pizzas/count")
            .then()
                .statusCode(200);
    }

     @Test
    public void getByIdTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(1l);
        sabores.add(2l);

        PizzaDTO pizza = new PizzaDTO(
            "CalabrezaMista",
            "Catupiry",
                1l, 
                70.0,
                20,
                2,
                2,
                2,
                sabores);

        Long id = pizzaService.insert(pizza).id();

        given()
            .when().get("/pizzas/" + id)
            .then()
                .statusCode(200);
    }

    @Test
    public void getByNomeTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(3l);
        sabores.add(4l);
        PizzaDTO pizza = new PizzaDTO(
            "ModaMista",
            "Catupiry",
                1l, 
                70.0,
                20,
                4,
                4,
                2,
                sabores);

        String nome = pizzaService.insert(pizza).nome();

        given()
            .when().get("/pizzas/searchByNome/" + nome)
            .then()
                .statusCode(200);
    }

    @Test
    public void getByCategoriaTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(3l);
        sabores.add(4l);

        PizzaDTO pizza = new PizzaDTO(
            "ModaMista",
            "Catupiry",
                1l, 
                70.0,
                20,
                4,
                4,
                2,
                sabores);

        Integer categoria = pizzaService.insert(pizza).categoria().getId();

        given()
            .when().get("/pizzas/searchByCategoria/" + categoria)
            .then()
                .statusCode(200);
    }

    @Test
    public void getByTamanhoEmbalagemTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(3l);
        sabores.add(4l);
        PizzaDTO pizza = new PizzaDTO(
            "ModaMista",
            "Catupiry",
                1l, 
                70.0,
                20,
                4,
                4,
                2,
                sabores);

            Integer tamanhoEmbalagem = pizzaService.insert(pizza).tamanhoEmbalagem().getId();

        given()
            .when().get("/pizzas/searchByTamanhoEmbalagem/" + tamanhoEmbalagem)
            .then()
                .statusCode(200);
    }

    @Test
    public void getByTamanhoPizzaTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(3l);
        sabores.add(4l);
        PizzaDTO pizza = new PizzaDTO(
            "ModaMista",
            "Catupiry",
                1l, 
                70.0,
                20,
                4,
                4,
                2,
                sabores);

        Integer tamanhoPizza = pizzaService.insert(pizza).tamanhoPizza().getId();

        given()
            .when().get("/pizzas/searchByTamanhoPizza/" + tamanhoPizza)
            .then()
                .statusCode(200);
    }

    @Test
    public void getByMarcaTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(3l);
        sabores.add(4l);
        PizzaDTO pizza = new PizzaDTO(
            "ModaMista",
            "Catupiry",
                 1l,
                70.0,
                20,
                4,
                4,
                2,
                sabores);

        String marca= pizzaService.insert(pizza).nomeMarca();

        given()
            .when().get("/pizzas/searchByMarca/" + marca)
            .then()
                .statusCode(200);
    }

    /*************************************************************** */
    @Test
    public void filterByPrecoMinTest() {

        Double precoMinimo = 60.0;


        given()
            .when().get("/pizzas/filterByPrecoMin/" + precoMinimo)
            .then()
                .statusCode(200);

    }

    @Test
    public void filterByPrecoMaxTest() {

        Double precoMaximo = 160.0;


        given()
            .when().get("/pizzas/filterByPrecoMax/" + precoMaximo)
            .then()
                .statusCode(200);

    }

     @Test
     public void filterByEntrePrecoTest() {

         Double precoMaximo = 160.0;
         Double precoMinimo = 60.0;

         given()
             .when().get("/pizzas/filterByEntrePreco/" + precoMaximo + "/" +precoMinimo)
            .then()
                 .statusCode(200);

    }
}

